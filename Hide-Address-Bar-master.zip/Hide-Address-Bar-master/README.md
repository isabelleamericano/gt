A normalized approach to hiding the address bar on iOS and Android
=======================

Authored by @scottjehl

MIT License.

Read this article for explanation
http://24ways.org/2011/raising-the-bar-on-mobile